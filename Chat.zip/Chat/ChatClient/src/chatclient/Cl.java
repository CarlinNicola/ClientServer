/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.shape.Mesh;

/**
 *
 * @author Nicola
 */
public class Cl extends Thread{
    
    BufferedReader in = null;
    PrintStream out = null;
    private Client cl;
    private int i;
    Socket socket;
    
    public Cl(Client cl)
    {
        this.cl = cl;
        i = 0;
        //this.start();
    };
    
    @Override
    public void run()
    {    

            try
            {
                socket = new Socket("localhost", 4000);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintStream(socket.getOutputStream(), true);                        
                
            }
            catch(Exception e)
            {
                
                System.out.println(e.getMessage());
            }
            
            while(true)
            {
                try {
                    cl.getTxtMessaggi().setText(cl.getTxtMessaggi().getText() + "\n" + in.readLine());
                } catch (IOException ex) {
                    Logger.getLogger(Cl.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    }
    
    public void connect()
    {
        if(i == 0)
        {
            this.start();
            i++;
        }
        else
        {
            cl.getUser().setText("Gia loggato");
        }
    }
    
    public void disconnetti()
    {
        try
        { 
            out = new PrintStream(socket.getOutputStream(), true);

            out.println("Disconnetti");            

            try
            {
                socket.close();
            }
            catch(Exception e)
            {
            System.out.println(e.getMessage());
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    
    public void invia(String Testo)
    {     
            try
            { 
                out = new PrintStream(socket.getOutputStream(), true);
                
                out.println(Testo);
                //out.close();
                
                String testo = cl.getTxtMessaggi().getText();
                       
                try {
                    String message = in.readLine();
                    
                    if(controllo(message) == true)
                    {
                        cl.getTxtMessaggi().setText(testo + "" + message + "\n ");
                        out.println(message);
                    }
                } catch (IOException ex) {
                    Logger.getLogger(Cl.class.getName()).log(Level.SEVERE, null, ex);
                }

                }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        
    }
    
    public boolean controllo(String message)
    {
        String[] array;
        array = message.split(" ");
        boolean controllo = true;
        
        if(array[0].equals(socket.getPort()))
        {
            controllo = false;
        }
        
        return controllo;
    }
    
}
