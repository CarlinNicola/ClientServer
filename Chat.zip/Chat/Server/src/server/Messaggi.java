/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Nicola
 */
public class Messaggi extends Thread{

    private Connect c;
    private Server s;
    private BufferedReader in;
    private ArrayList<PrintStream> out;
    private Socket cl;
    private int i;
    
    public Messaggi(Connect c, Server s, BufferedReader in, ArrayList<PrintStream> out, Socket cl, int i) 
    {
        this.c = c;  
        this.s = s;  
        this.in = in;
        this.out = out;
        this.cl = cl;
        this.i = i;
    }   
    
    
    @Override
    public void run() {
        
        String testo;
        String aggiungi = "";
        while(true)
        {              
                       
            try {
                
                String message = in.readLine();
                if(message.equals("Disconnetti"))
                {
                    s.cl.remove(i);
                    s.setUser("" + cl.getPort() + " disconnesso");
                }
                else
                {
                    testo = c.getMessaggi();
                    aggiungi = cl.getPort() + " " + message + "\n";
                    c.getMess().setText(testo + "" + aggiungi);
                    c.setMessaggi(testo);
                }
                
                for(int i = 0; i < out.size(); i++)
                {
                    out.get(i).println(aggiungi);
                }
                
            } catch (IOException ex) {
                Logger.getLogger(Messaggi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }   
      
    
}
