/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author nicola.carlin
 */

import com.sun.media.sound.SF2Layer;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server extends Thread
{

    private ServerSocket server;
    private ServerForm sF;
    public static ArrayList <Socket>cl;
    private int i;
    public static Messaggi m;
      
        
    public Server(ServerForm serv) throws Exception
    {
        server = new ServerSocket(4000); 
        sF = serv;
        cl = new ArrayList<Socket>();
        i = 0;
        
        System.out.println("Il server è in attesa sulla porta 4000");
        this.start();
               
        
    };
    
    
    @Override
    public void run()
    {
        String utenti;
        while(true)
        {
            try
            {
                //System.out.println("In attesa di connessione");
                Socket client = server.accept();
                //System.out.println("Connessione accettata da: " + client.getInetAddress()); 
                this.cl.add(client);
                utenti = sF.getUtenti().toString();
                sF.getTxtUsers().setText(utenti + "" + client.getInetAddress().toString() + " " + client.getPort() + " connesso \n");
                i++;               
                Connect c = new Connect(sF, this, client, i);
                
            }
            catch(Exception e)
            {
                
            }
        }        
    };
    
    public String getTxtMessa()
    {
        return sF.getTxtMessaggi().getText();
    }
    
    public void setUser(String s)
    {
        sF.getTxtUsers().setText(sF.getTxtUsers().getText() + s);
    }
    
    
}

    
class Connect extends Thread
{
    BufferedReader in = null;
    ArrayList<PrintStream> out = new ArrayList<PrintStream>();
    private ServerForm server;
    private static Socket client;
    private int i;
    private Server s;

    public Connect()
    {}

    public Connect (ServerForm sF, Server s, Socket cl, int i)
    {
        server = sF;
        this.s = s;
        client = cl;
        this.i = i - 1;
                
        
        try
        {
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            out.add(new PrintStream(client.getOutputStream(), true));
        }
        catch(Exception el)
        {
            /*
            try
            {
                client.close();                    
            }
            catch(Exception ell)
            {
                System.out.println(ell.getMessage());
            }

            return;
            */
        }
          
        

        this.start();
    }
    
    @Override
    public void run()
    {
        s.m = new Messaggi(this, s, in, out, client, i);
        s.m.start();
        
        while(true)
        {                       
            
            try
            {
                out.get(i).println("Messaggio per il client che si è connesso");
                out.get(i).flush();
                
            }
            catch(Exception e)
            {
                
            }
            return;
            
        }
    }
    
    public javax.swing.JTextPane getMess()
    {
        return server.getTxtMessaggi();
    }   

    
    public String getTxtMess()
    {
        return s.getTxtMessa();
    }
    
    public String getMessaggi()
    {
        return server.testoMessaggi;
    }
    
    public void setMessaggi(String t)
    {
        server.testoMessaggi = server.testoMessaggi + t;
    }
}
