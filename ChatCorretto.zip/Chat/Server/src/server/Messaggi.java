/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Nicola
 */
public class Messaggi extends Thread{

    private Connect c;
    private Server s;
    private BufferedReader in;
    private Socket cl;
    private int i;
    
    public Messaggi(Connect c, Server s, BufferedReader in, Socket cl, int i) 
    {
        this.c = c;  
        this.s = s;  
        this.in = in;
        this.cl = cl;
        this.i = i;
    }   
    
    
    @Override
    public void run() {
        
        String testo;
        String aggiungi = "";
        while(true)
        {              
                       
            try {
                
                String message = in.readLine();
                //Controlla se indica disconnessione
                if(message.equals("Disconnetti"))
                {
                    s.cl.remove(i);
                    s.setUser("" + c.getUser() + " disconnesso\n");
                }
                else
                {
                    //Stampa messaggio a video sul server e lo invia a tutti i client
                    testo = c.getMess();
                    aggiungi = c.getUser() + ": " + message;
                    c.setMess(testo + "" + aggiungi + "\n");
                    
                    for(int i = 0; i < s.out.size(); i++)
                    {
                        s.out.get(i).println(aggiungi);
                    }
                    
                }
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Messaggi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }   
      
    
}
