/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.shape.Mesh;

/**
 *
 * @author Nicola
 */
public class Cl extends Thread{
    
    BufferedReader in = null;
    PrintStream out = null;
    private Client cl;
    private int i;
    Socket socket;
    private String user;
    
    public Cl(Client cl)
    {
        this.cl = cl;
        i = 0;
    };
    
    @Override
    public void run()
    {    

            try
            {
                socket = new Socket("10.0.74.24", 4000);         
                
                user = cl.getUsername();
                
                if(cl.getShowStatus() == true)
                {
                    user = user + " check";
                }
                else
                {
                    user = user + " uncheck";
                }
                
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintStream(socket.getOutputStream(), true); 
                out.println(user);
                
            }
            catch(Exception e)
            {
                
                System.out.println(e.getMessage());
            }
            
            while(true)
            {
                try {
                    cl.setMessaggi(cl.getMessaggi() + in.readLine() + "\n");
                } catch (IOException ex) {
                    Logger.getLogger(Cl.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    }
    
    public void connect()
    {
        if(i == 0)
        {                                    
            this.start();
            i++;
        }
        else
        {
            cl.setUser("Gia loggato");
        }
    }
    
    public void disconnetti()
    {
        try
        { 
            out = new PrintStream(socket.getOutputStream(), true);

            out.println("Disconnetti");   
                        
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    
    public void invia(String Testo)
    {     
            try
            { 
                out = new PrintStream(socket.getOutputStream(), true);
                
                out.println(Testo);
                
                cl.setMessaggio();
            }
                
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        
    }
    
}
